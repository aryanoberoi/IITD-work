from myfunctions import analyze_sentiment
text=input("enter data")
hello=str(analyze_sentiment(text))
print(hello)

